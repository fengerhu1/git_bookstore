import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import {HashRouter, Switch, Route, Link } from 'react-router-dom'
import './index.css';
import Home from './Home';
import Login from './Login';
import Shopcar from './Shopcar'
import Bookdemo from './Bookdemo'
import registerServiceWorker from './registerServiceWorker';

/*class RouteMap extends React.Component {
    updateHandle() {
        console.log('每次router变化之后都会触发')
    }
    render() {
        return (
            <Router history={this.props.history} onUpdate={this.updateHandle.bind(this)}>
                <Route path='/' component={Home}>
                    <Route path='list' component={Home}/>

                </Route>
            </Router>
        )
    }
}*/

//export default RouteMap

//<Time initialData= {data} headers= {headers}/>
/*var Ex = ReactDOM.render(
    <Home/>,
    document.getElementById('app')
);*/

//ReactDOM.render(<App />, document.getElementById('app'));
//function tick() {
//    ReactDOM.render(<Time />, document.getElementById('root2'));
//}
const Main = () => (
    <main>
        <Switch>
            <Route exact path='/' component={Home}/>
            <Route path='/login' component={Login}/>
            <Route path='/shopcar' component={Shopcar}/>
            <Route path='/bookdemo' component={Bookdemo}/>
        </Switch>
    </main>
)
var Ex = ReactDOM.render(
    <HashRouter>
        <Main />
    </HashRouter>,
    document.getElementById('app')
)
registerServiceWorker();
