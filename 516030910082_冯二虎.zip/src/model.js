/**
 * Created by lenovo on 2018/3/19.
 */
import React, { Component } from 'react';
class Header extends Component {
    render() {
        return (
            
        );
    }
}

export default Header;